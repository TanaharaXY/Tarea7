
package act7;

import java.util.Scanner;


public class Act7 {

   
    public static void main(String[] args) {
        
        
        
        int num, fibon;
        
        Scanner leer = new Scanner(System.in);
        System.out.println("Cuantos numeros primos quieres ver: ");
        num = leer.nextInt();
        System.out.println("Cuantos numeros de Fibonacci quieres ver:");
        fibon = leer.nextInt();
                
        Primos lista = new Primos();
        Fibonacci lista2 = new Fibonacci();
        
        int[] Primo = lista.generar(num);
        int[] Fibo = lista2.generar(fibon);
        
        System.out.println("Numeros primos");
        for(int i = 0; i <= num; i++)
        {
            System.out.println(Primo[i]);
        }
        
        System.out.println("Fibonacci");
        for(int i = 0; i <= num; i++)
        {
            System.out.println(Fibo[i]);
        }
        
        
        
        
        
    
    }
    
}
