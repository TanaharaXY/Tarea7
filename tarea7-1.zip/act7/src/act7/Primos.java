/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act7;

/**
 *
 * @author Fredo
 */
public class Primos {
    
    int limite;
    int Primo[] = new int[100];
    int indice = 0;
    
    public int[] generar(int limite)
    {
        for(int i = 1; i <= limite; i++)
        {
            int cont = 0;
            
            for(int j = 1; j <= limite; j++)
            {
                if(i % j == 0)
                {
                    cont++;
                }
            }
            
            if(cont == 2)
            {
                Primo[indice++] = i;
            }
        }
        
        return Primo;
    }
    
}
