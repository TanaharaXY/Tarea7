/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act7;

/**
 *
 * @author Fredo
 */
public class Fibonacci {
    
     int[] Fibo = new int[100];
    public int[] generar(int limite)
    {
        int fibo = 0;
        int aux = 1;
        int aux2;
        
        for(int i = 0; i <= limite; i++)
        {
            aux2 = fibo;
            fibo = aux + fibo;
            aux = aux2;
            Fibo[i] = aux;
        }
        
        return Fibo;
    }
}
